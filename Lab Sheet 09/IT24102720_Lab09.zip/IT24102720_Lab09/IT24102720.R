getwd()
setwd("D:\\YEAR 2\\PS\\PS LAB\\IT24102720_Lab09")

#Exercise
#1
#i
y <- rnorm(25, mean=45, sd = 2)

##ii
t.test(y, mu=46, alternative= "less")
